# V-Taper Tracker

Bodyweight workout tracker for 27 Oct to 29 Dec 2026. React, TypeScript, Tailwind, Lucide, Recharts (charts come in the next step). Everything saves to your browser's local storage.

## Run it

Needs Node 18 or newer.

```bash
npm install
npm test        # runs the persistence tests
npm run dev     # opens at http://localhost:5173
```

Other commands: `npm run build` (typecheck and production build), `npm run preview` (serve the build).

## What works in this first step

- Calendar for Oct, Nov and Dec 2026. Tap a day to open it. Completed, missed, upcoming and rest days look different.
- Workout checklist per day: tick each exercise, enter reps for each set, mark the workout complete, reopen it.
- Autosave on every change, plus a Save progress button. Data is stored under the key `vtaper:workouts:v1`.
- Weekly schedule: Mon chest and shoulders, Tue back and biceps, Thu chest, shoulders and triceps, Sat legs and core. Wed, Fri and Sun are rest.

## Change the exercises, sets or targets

Edit `src/lib/plan.ts`. Targets like "10–15 reps" are starting suggestions, not prescriptions.

## Tests

- `src/App.persistence.test.tsx` ticks exercises, types reps, completes a workout, then throws the app away and mounts a fresh copy to check everything is still there. It also checks corrupted storage does not crash the app.
- `src/lib/plan.test.ts` checks the date range (64 days) and the planned workout count (37).

## Reset your data

In the browser console: `localStorage.removeItem('vtaper:workouts:v1')`, then refresh.
