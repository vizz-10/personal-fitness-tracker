/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0F1B2D',
        chalk: { DEFAULT: '#EDF0F4', 2: '#E1E6ED' },
        cobalt: { DEFAULT: '#1D4ED8', dark: '#1E3FA8' },
        done: { DEFAULT: '#15803D', soft: '#DDF3E4' },
        miss: '#B42318',
      },
      fontFamily: {
        sans: ['"Archivo Variable"', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
