import type { DateKey } from './dates';
import type { DayPlan } from './plan';
import type { DayLog, WorkoutLogs } from './types';

export const emptyDayLog = (plan: DayPlan): DayLog => ({
  exercises: Object.fromEntries(plan.exercises.map((e) => [e.id, { done: false, reps: Array<string>(e.sets).fill('') }])),
  completed: false,
});

/**
 * The log for a day, shaped to match today's plan. Safe to call for days with no
 * saved data, and tolerant of saved data written for a slightly different plan.
 */
export function getDayLog(logs: WorkoutLogs, date: DateKey, plan: DayPlan): DayLog {
  const base = emptyDayLog(plan);
  const saved = logs[date];
  if (!saved) return base;
  const exercises = { ...base.exercises };
  for (const e of plan.exercises) {
    const ex = saved.exercises?.[e.id];
    if (ex) {
      exercises[e.id] = {
        done: Boolean(ex.done),
        reps: Array.from({ length: e.sets }, (_, i) => String(ex.reps?.[i] ?? '')),
      };
    }
  }
  return { ...saved, exercises };
}

const stamp = () => new Date().toISOString();

export function toggleExercise(logs: WorkoutLogs, date: DateKey, plan: DayPlan, exerciseId: string): WorkoutLogs {
  const day = getDayLog(logs, date, plan);
  const ex = day.exercises[exerciseId];
  if (!ex) return logs;
  return {
    ...logs,
    [date]: { ...day, exercises: { ...day.exercises, [exerciseId]: { ...ex, done: !ex.done } }, updatedAt: stamp() },
  };
}

export function setReps(
  logs: WorkoutLogs,
  date: DateKey,
  plan: DayPlan,
  exerciseId: string,
  setIndex: number,
  value: string,
): WorkoutLogs {
  const day = getDayLog(logs, date, plan);
  const ex = day.exercises[exerciseId];
  if (!ex) return logs;
  const reps = ex.reps.map((v, i) => (i === setIndex ? value : v));
  return {
    ...logs,
    [date]: { ...day, exercises: { ...day.exercises, [exerciseId]: { ...ex, reps } }, updatedAt: stamp() },
  };
}

export function setCompleted(logs: WorkoutLogs, date: DateKey, plan: DayPlan, completed: boolean): WorkoutLogs {
  const day = getDayLog(logs, date, plan);
  const next: DayLog = { ...day, completed, updatedAt: stamp() };
  if (completed) next.completedAt = stamp();
  else delete next.completedAt;
  return { ...logs, [date]: next };
}
