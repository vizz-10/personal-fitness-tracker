/** Dates are handled as local "YYYY-MM-DD" keys so time zones and DST never shift a day. */
export type DateKey = string;

const pad = (n: number) => String(n).padStart(2, '0');

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const toKey = (d: Date): DateKey => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const fromKey = (k: DateKey): Date => {
  const [y, m, d] = k.split('-').map(Number);
  return new Date(y, m - 1, d);
};

export const addDays = (k: DateKey, n: number): DateKey => {
  const d = fromKey(k);
  d.setDate(d.getDate() + n);
  return toKey(d);
};

/** Whole days from `from` to `to` (negative if `to` is earlier). */
export const diffDays = (from: DateKey, to: DateKey): number =>
  Math.round((fromKey(to).getTime() - fromKey(from).getTime()) / 86_400_000);

/** 0 = Sunday ... 6 = Saturday */
export const weekday = (k: DateKey): number => fromKey(k).getDay();

/** Monday of the week containing `k`. */
export const startOfWeek = (k: DateKey): DateKey => addDays(k, -((weekday(k) + 6) % 7));

export const eachDay = (start: DateKey, end: DateKey): DateKey[] => {
  const out: DateKey[] = [];
  for (let k = start; k <= end; k = addDays(k, 1)) out.push(k);
  return out;
};

/** "Tuesday, 27 October" */
export const formatLong = (k: DateKey): string => {
  const d = fromKey(k);
  return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
};

/** "27 Oct" */
export const formatShort = (k: DateKey): string => {
  const d = fromKey(k);
  return `${d.getDate()} ${MONTHS[d.getMonth()].slice(0, 3)}`;
};

/** "October 2026" from "2026-10" */
export const monthLabel = (ym: string): string => {
  const [y, m] = ym.split('-').map(Number);
  return `${MONTHS[m - 1]} ${y}`;
};
