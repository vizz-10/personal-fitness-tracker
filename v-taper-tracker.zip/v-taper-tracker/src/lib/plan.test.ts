import { getPlanDay, WORKOUT_DATES, PLAN_START, PLAN_END } from './plan';
import { diffDays } from './dates';

describe('plan', () => {
  it('spans 27 Oct to 29 Dec 2026 (64 days)', () => {
    expect(diffDays(PLAN_START, PLAN_END) + 1).toBe(64);
  });

  it('has 37 planned workouts (9 full weeks of 4, plus the final Tuesday)', () => {
    expect(WORKOUT_DATES).toHaveLength(37);
    expect(WORKOUT_DATES[0]).toBe('2026-10-27');
    expect(WORKOUT_DATES[WORKOUT_DATES.length - 1]).toBe('2026-12-29');
  });

  it('follows the weekly schedule', () => {
    expect(getPlanDay('2026-10-26')).toBeNull(); // Monday before the start
    expect(getPlanDay('2026-10-27')?.title).toBe('Back & biceps'); // Tue
    expect(getPlanDay('2026-10-28')).toBeNull(); // Wed rest
    expect(getPlanDay('2026-10-29')?.title).toBe('Chest, shoulders & triceps'); // Thu
    expect(getPlanDay('2026-10-30')).toBeNull(); // Fri rest
    expect(getPlanDay('2026-10-31')?.title).toBe('Legs & core'); // Sat
    expect(getPlanDay('2026-11-01')).toBeNull(); // Sun rest
    expect(getPlanDay('2026-11-02')?.title).toBe('Chest & shoulders'); // Mon
    expect(getPlanDay('2026-12-30')).toBeNull(); // after the end
  });
});
