import type { DateKey } from './dates';

export interface ExerciseLog {
  done: boolean;
  /** One entry per set. Stored as strings so an empty box stays empty. */
  reps: string[];
}

export interface DayLog {
  exercises: Record<string, ExerciseLog>;
  completed: boolean;
  completedAt?: string;
  updatedAt?: string;
}

export type WorkoutLogs = Record<DateKey, DayLog>;
