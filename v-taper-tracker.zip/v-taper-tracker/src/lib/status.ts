import type { DateKey } from './dates';
import { getPlanDay, isInPlan } from './plan';
import type { WorkoutLogs } from './types';

export type DayStatus = 'outside' | 'rest' | 'done' | 'missed' | 'open' | 'upcoming';

export function dayStatus(k: DateKey, logs: WorkoutLogs, today: DateKey): DayStatus {
  if (!isInPlan(k)) return 'outside';
  if (!getPlanDay(k)) return 'rest';
  if (logs[k]?.completed) return 'done';
  if (k < today) return 'missed';
  return k === today ? 'open' : 'upcoming';
}
