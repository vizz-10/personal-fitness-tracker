import { useCallback, useEffect, useRef, useState } from 'react';
import { loadJSON, saveJSON } from './storage';

/**
 * State that lives in localStorage. Loads once on mount, saves after every change,
 * and flushes again when the tab is hidden or closed.
 */
export function usePersistentState<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => loadJSON<T>(key, initial));
  const baseline = useRef(state);
  const latest = useRef(state);
  latest.current = state;

  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [saveError, setSaveError] = useState(false);

  /** Writes the current state now. Used by autosave and the Save button. */
  const flush = useCallback(() => {
    const ok = saveJSON(key, latest.current);
    setSaveError(!ok);
    if (ok) setSavedAt(Date.now());
    return ok;
  }, [key]);

  useEffect(() => {
    if (state === baseline.current) return; // nothing changed yet, don't overwrite storage
    flush();
  }, [state, flush]);

  useEffect(() => {
    const onLeave = () => {
      if (latest.current !== baseline.current) saveJSON(key, latest.current);
    };
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') onLeave();
    };
    window.addEventListener('pagehide', onLeave);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('pagehide', onLeave);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [key]);

  return { state, setState, savedAt, saveError, flush };
}
