import { eachDay, weekday, type DateKey } from './dates';

export const PLAN_START: DateKey = '2026-10-27';
export const PLAN_END: DateKey = '2026-12-29';

export interface Exercise {
  id: string;
  name: string;
  sets: number;
  /** Target shown to you, e.g. "10–15 reps". Edit freely. */
  target: string;
  unit: 'reps' | 'sec';
  tip?: string;
}

export interface DayPlan {
  title: string;
  /** Short tag shown on calendar cells. */
  short: string;
  exercises: Exercise[];
}

const pushUps: Exercise = { id: 'push-ups', name: 'Push-ups', sets: 3, target: '10–15 reps', unit: 'reps' };
const pike: Exercise = {
  id: 'pike-push-ups',
  name: 'Pike push-ups',
  sets: 3,
  target: '8–12 reps',
  unit: 'reps',
  tip: 'Hips high, head moves toward the floor between your hands.',
};

/** Keyed by weekday number (0 = Sunday). Missing key = rest day. */
export const WEEK_PLAN: Record<number, DayPlan | undefined> = {
  1: {
    title: 'Chest & shoulders',
    short: 'Push A',
    exercises: [
      pushUps,
      pike,
      { id: 'wide-push-ups', name: 'Wide push-ups', sets: 3, target: '10–15 reps', unit: 'reps' },
    ],
  },
  2: {
    title: 'Back & biceps',
    short: 'Pull',
    exercises: [
      {
        id: 'prone-y-raises',
        name: 'Prone Y raises',
        sets: 3,
        target: '10–12 reps',
        unit: 'reps',
        tip: 'Lie face down, lift arms in a Y, thumbs up. Squeeze your shoulder blades.',
      },
      {
        id: 'prone-t-raises',
        name: 'Prone T raises',
        sets: 3,
        target: '10–12 reps',
        unit: 'reps',
        tip: 'Lie face down, lift arms out to the sides in a T.',
      },
      {
        id: 'reverse-snow-angels',
        name: 'Reverse snow angels',
        sets: 3,
        target: '12–15 reps',
        unit: 'reps',
        tip: 'Face down, sweep straight arms from your sides to overhead, hovering off the floor.',
      },
      {
        id: 'self-resisted-curls',
        name: 'Self-resisted biceps curls',
        sets: 3,
        target: '10–12 reps per arm',
        unit: 'reps',
        tip: 'Curl one hand up while the other hand pushes down against it. Go slowly.',
      },
    ],
  },
  4: {
    title: 'Chest, shoulders & triceps',
    short: 'Push B',
    exercises: [
      pushUps,
      pike,
      {
        id: 'close-grip-push-ups',
        name: 'Close-grip push-ups',
        sets: 3,
        target: '8–12 reps',
        unit: 'reps',
        tip: 'Hands under your chest, elbows brushing your ribs.',
      },
      { id: 'wall-push-ups', name: 'Wall push-ups', sets: 3, target: '15–20 reps', unit: 'reps' },
    ],
  },
  6: {
    title: 'Legs & core',
    short: 'Legs',
    exercises: [
      { id: 'bodyweight-squats', name: 'Bodyweight squats', sets: 3, target: '15–20 reps', unit: 'reps' },
      { id: 'reverse-lunges', name: 'Reverse lunges', sets: 3, target: '10 reps per leg', unit: 'reps' },
      { id: 'glute-bridges', name: 'Glute bridges', sets: 3, target: '15–20 reps', unit: 'reps' },
      { id: 'planks', name: 'Planks', sets: 3, target: '30–45 seconds', unit: 'sec' },
    ],
  },
};

export const isInPlan = (k: DateKey): boolean => k >= PLAN_START && k <= PLAN_END;

export const getPlanDay = (k: DateKey): DayPlan | null => (isInPlan(k) ? (WEEK_PLAN[weekday(k)] ?? null) : null);

/** Every date in the plan that has a workout, in order. */
export const WORKOUT_DATES: DateKey[] = eachDay(PLAN_START, PLAN_END).filter((k) => WEEK_PLAN[weekday(k)]);

export const nextWorkoutAfter = (k: DateKey): DateKey | null => WORKOUT_DATES.find((d) => d > k) ?? null;

export const clampToPlan = (k: DateKey): DateKey => (k < PLAN_START ? PLAN_START : k > PLAN_END ? PLAN_END : k);
