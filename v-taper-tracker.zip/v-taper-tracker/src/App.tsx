import { useMemo, useState } from 'react';
import { WorkoutCalendar } from './components/WorkoutCalendar';
import { RestDay, WorkoutDay } from './components/WorkoutDay';
import { formatShort, toKey, type DateKey } from './lib/dates';
import { getDayLog, setCompleted, setReps, toggleExercise } from './lib/logic';
import { PLAN_END, PLAN_START, clampToPlan, getPlanDay } from './lib/plan';
import { KEYS } from './lib/storage';
import type { WorkoutLogs } from './lib/types';
import { usePersistentState } from './lib/usePersistentState';

function Logo() {
  return (
    <svg viewBox="0 0 32 32" width="36" height="36" aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="#0F1B2D" />
      <path d="M6 8h20l-7.5 16h-5z" fill="#FFFFFF" />
    </svg>
  );
}

/** `todayKey` lets tests pin the date. In normal use it is today's date. */
export default function App({ todayKey }: { todayKey?: DateKey }) {
  const today = useMemo(() => todayKey ?? toKey(new Date()), [todayKey]);
  const [selected, setSelected] = useState<DateKey>(() => clampToPlan(today));
  const {
    state: logs,
    setState: setLogs,
    savedAt,
    saveError,
    flush,
  } = usePersistentState<WorkoutLogs>(KEYS.workouts, {});

  const plan = getPlanDay(selected);

  return (
    <div className="mx-auto min-h-screen max-w-5xl px-4 pb-16 pt-5 sm:px-6">
      <header className="mb-6 flex items-center gap-3">
        <Logo />
        <div>
          <h1 className="text-2xl font-extrabold leading-tight">V-Taper Tracker</h1>
          <p className="text-sm text-ink/70">
            Bodyweight plan, {formatShort(PLAN_START)} to {formatShort(PLAN_END)} 2026
          </p>
        </div>
      </header>

      <main className="grid gap-6 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
        <WorkoutCalendar logs={logs} todayKey={today} selected={selected} onSelect={setSelected} />

        {plan ? (
          <WorkoutDay
            dateKey={selected}
            plan={plan}
            log={getDayLog(logs, selected, plan)}
            todayKey={today}
            savedAt={savedAt}
            saveError={saveError}
            onToggle={(id) => setLogs((p) => toggleExercise(p, selected, plan, id))}
            onReps={(id, i, v) => setLogs((p) => setReps(p, selected, plan, id, i, v))}
            onComplete={(done) => setLogs((p) => setCompleted(p, selected, plan, done))}
            onSave={flush}
          />
        ) : (
          <RestDay dateKey={selected} />
        )}
      </main>
    </div>
  );
}
