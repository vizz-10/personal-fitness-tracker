import { useState } from 'react';
import { Check, ChevronLeft, ChevronRight } from 'lucide-react';
import { WEEKDAYS, formatLong, monthLabel, type DateKey } from '../lib/dates';
import { PLAN_END, PLAN_START, getPlanDay } from '../lib/plan';
import { dayStatus, type DayStatus } from '../lib/status';
import type { WorkoutLogs } from '../lib/types';

interface Props {
  logs: WorkoutLogs;
  todayKey: DateKey;
  selected: DateKey;
  onSelect: (k: DateKey) => void;
}

const CELL: Record<DayStatus, string> = {
  outside: 'border-transparent text-ink/35',
  rest: 'border-transparent bg-chalk-2 text-ink/70',
  done: 'border-done/50 bg-done-soft text-done',
  missed: 'border-miss/40 bg-white text-miss',
  open: 'border-ink bg-white text-ink',
  upcoming: 'border-ink/15 bg-white text-ink',
};

const STATUS_WORD: Record<DayStatus, string> = {
  outside: 'outside the plan',
  rest: 'rest day',
  done: 'completed',
  missed: 'not completed',
  open: 'today, to do',
  upcoming: 'upcoming',
};

const pad = (n: number) => String(n).padStart(2, '0');

export function WorkoutCalendar({ logs, todayKey, selected, onSelect }: Props) {
  const [month, setMonth] = useState(() => selected.slice(0, 7));
  const [y, m] = month.split('-').map(Number);
  const lead = (new Date(y, m - 1, 1).getDay() + 6) % 7; // weeks start on Monday
  const daysInMonth = new Date(y, m, 0).getDate();

  const shift = (delta: number) => {
    const d = new Date(y, m - 1 + delta, 1);
    setMonth(`${d.getFullYear()}-${pad(d.getMonth() + 1)}`);
  };
  const canPrev = month > PLAN_START.slice(0, 7);
  const canNext = month < PLAN_END.slice(0, 7);

  const cells: (DateKey | null)[] = [
    ...Array<null>(lead).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => `${month}-${pad(i + 1)}`),
  ];

  return (
    <section aria-label="Workout calendar">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-xl font-bold">{monthLabel(month)}</h2>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => shift(-1)}
            disabled={!canPrev}
            aria-label="Previous month"
            className="flex h-11 w-11 items-center justify-center rounded-lg border border-ink/20 bg-white disabled:opacity-30"
          >
            <ChevronLeft aria-hidden size={20} />
          </button>
          <button
            type="button"
            onClick={() => shift(1)}
            disabled={!canNext}
            aria-label="Next month"
            className="flex h-11 w-11 items-center justify-center rounded-lg border border-ink/20 bg-white disabled:opacity-30"
          >
            <ChevronRight aria-hidden size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
        {WEEKDAYS.slice(1)
          .concat(WEEKDAYS[0])
          .map((d) => (
            <div key={d} className="pb-1 text-center text-xs font-semibold text-ink/70" aria-hidden>
              {d.slice(0, 3)}
            </div>
          ))}

        {cells.map((k, i) => {
          if (!k) return <div key={`blank-${i}`} />;
          const status = dayStatus(k, logs, todayKey);
          const plan = getPlanDay(k);
          const isToday = k === todayKey;
          const isSelected = k === selected;
          const label = `${formatLong(k)}: ${plan ? plan.title : status === 'outside' ? '' : 'Rest day'}${
            plan ? ', ' : status === 'outside' ? '' : ', '
          }${STATUS_WORD[status]}`;
          return (
            <button
              key={k}
              type="button"
              disabled={status === 'outside'}
              onClick={() => onSelect(k)}
              aria-label={label}
              aria-pressed={isSelected}
              aria-current={isToday ? 'date' : undefined}
              className={`relative flex aspect-square min-h-[3rem] flex-col items-start justify-between rounded-md border p-1 text-left transition-colors sm:p-1.5 ${CELL[status]} ${
                isSelected ? 'ring-2 ring-cobalt ring-offset-2 ring-offset-chalk' : ''
              } ${status === 'outside' ? 'cursor-default' : 'cursor-pointer'}`}
            >
              <span
                className={`flex h-6 min-w-6 items-center justify-center rounded-full px-1 text-sm font-bold tabular-nums ${
                  isToday ? 'bg-cobalt text-white' : ''
                }`}
              >
                {Number(k.slice(8))}
              </span>
              {plan && (
                <span className="flex w-full items-end justify-between gap-1">
                  <span className="truncate text-[10px] font-semibold leading-none sm:text-xs">{plan.short}</span>
                  {status === 'done' && <Check aria-hidden size={14} strokeWidth={3} />}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <ul className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink/70">
        <li className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm border border-done/50 bg-done-soft" /> Completed
        </li>
        <li className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm border border-miss/40 bg-white" /> Not completed
        </li>
        <li className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm border border-ink/15 bg-white" /> To do
        </li>
        <li className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm bg-chalk-2" /> Rest
        </li>
      </ul>
    </section>
  );
}
