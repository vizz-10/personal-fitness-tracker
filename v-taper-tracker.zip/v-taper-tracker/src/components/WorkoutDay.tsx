import { Check, Moon, RotateCcw, Save } from 'lucide-react';
import { formatLong, type DateKey } from '../lib/dates';
import { nextWorkoutAfter, getPlanDay, type DayPlan } from '../lib/plan';
import type { DayLog } from '../lib/types';

interface Props {
  dateKey: DateKey;
  plan: DayPlan;
  log: DayLog;
  todayKey: DateKey;
  savedAt: number | null;
  saveError: boolean;
  onToggle: (exerciseId: string) => void;
  onReps: (exerciseId: string, setIndex: number, value: string) => void;
  onComplete: (completed: boolean) => void;
  onSave: () => void;
}

const time = (ms: number) => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

export function WorkoutDay({
  dateKey,
  plan,
  log,
  todayKey,
  savedAt,
  saveError,
  onToggle,
  onReps,
  onComplete,
  onSave,
}: Props) {
  const ticked = plan.exercises.filter((e) => log.exercises[e.id]?.done).length;
  const total = plan.exercises.length;

  return (
    <section aria-label="Workout checklist" className="rounded-xl border border-ink/10 bg-white p-4 sm:p-6">
      <p className="text-sm text-ink/70">
        {formatLong(dateKey)}
        {dateKey === todayKey ? ' (today)' : ''}
      </p>
      <h2 className="text-2xl font-bold">{plan.title}</h2>

      <div className="mt-3 flex items-center gap-3">
        <div
          className="h-2 flex-1 overflow-hidden rounded-full bg-chalk-2"
          role="progressbar"
          aria-label="Exercises ticked"
          aria-valuemin={0}
          aria-valuemax={total}
          aria-valuenow={ticked}
        >
          <div className="h-full bg-done transition-all" style={{ width: `${(ticked / total) * 100}%` }} />
        </div>
        <p className="text-sm font-semibold tabular-nums">
          {ticked} of {total} ticked
        </p>
      </div>

      <ul className="mt-4 space-y-3">
        {plan.exercises.map((e) => {
          const ex = log.exercises[e.id];
          return (
            <li
              key={e.id}
              className={`rounded-lg border p-3 ${ex.done ? 'border-done/40 bg-done-soft/60' : 'border-ink/10 bg-white'}`}
            >
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={ex.done}
                  onChange={() => onToggle(e.id)}
                  aria-label={`Mark ${e.name} done`}
                  className="mt-0.5 h-6 w-6 shrink-0 cursor-pointer accent-done"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{e.name}</p>
                  <p className="text-sm text-ink/70">
                    {e.sets} sets of {e.target}
                  </p>
                  {e.tip && <p className="mt-0.5 text-sm text-ink/70">{e.tip}</p>}
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2 pl-9">
                {ex.reps.map((value, i) => (
                  <label key={i} className="flex flex-col text-xs font-medium text-ink/70">
                    Set {i + 1} ({e.unit})
                    <input
                      type="text"
                      inputMode="numeric"
                      autoComplete="off"
                      value={value}
                      placeholder="0"
                      onChange={(ev) => onReps(e.id, i, ev.target.value.replace(/\D/g, '').slice(0, 3))}
                      aria-label={`${e.name} set ${i + 1} ${e.unit}`}
                      className="mt-1 h-11 w-20 rounded-md border border-ink/25 bg-white text-center text-base font-semibold tabular-nums"
                    />
                  </label>
                ))}
              </div>
            </li>
          );
        })}
      </ul>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        {log.completed ? (
          <>
            <p className="flex items-center gap-2 font-bold text-done">
              <Check aria-hidden size={20} strokeWidth={3} />
              Workout complete
            </p>
            <button
              type="button"
              onClick={() => onComplete(false)}
              className="flex h-11 items-center gap-2 rounded-lg border border-ink/25 bg-white px-4 font-semibold"
            >
              <RotateCcw aria-hidden size={18} />
              Reopen workout
            </button>
          </>
        ) : (
          <button
            type="button"
            onClick={() => onComplete(true)}
            className="flex h-11 items-center gap-2 rounded-lg bg-cobalt px-5 font-semibold text-white hover:bg-cobalt-dark"
          >
            <Check aria-hidden size={18} strokeWidth={3} />
            Mark workout complete
          </button>
        )}
        <button
          type="button"
          onClick={onSave}
          className="flex h-11 items-center gap-2 rounded-lg border border-ink/25 bg-white px-4 font-semibold"
        >
          <Save aria-hidden size={18} />
          Save progress
        </button>
      </div>

      <p className="mt-3 text-sm text-ink/70" role="status">
        {saveError
          ? 'Could not save. Your browser blocked storage, or it is full. Leave private browsing and try again.'
          : savedAt
            ? `Saved at ${time(savedAt)}. Changes also save as you go.`
            : 'Changes save automatically on this device.'}
      </p>
    </section>
  );
}

export function RestDay({ dateKey }: { dateKey: DateKey }) {
  const next = nextWorkoutAfter(dateKey);
  const nextPlan = next ? getPlanDay(next) : null;
  return (
    <section aria-label="Rest day" className="rounded-xl border border-ink/10 bg-white p-4 sm:p-6">
      <p className="text-sm text-ink/70">{formatLong(dateKey)}</p>
      <h2 className="flex items-center gap-2 text-2xl font-bold">
        <Moon aria-hidden size={24} /> Rest day
      </h2>
      <p className="mt-2 max-w-prose text-ink/80">
        Muscle grows while you recover. Eat well, sleep, and stretch if you feel stiff.
      </p>
      {next && nextPlan && (
        <p className="mt-3 font-semibold">
          Next workout: {formatLong(next)}, {nextPlan.title}
        </p>
      )}
    </section>
  );
}
