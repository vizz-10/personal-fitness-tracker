import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';
import { KEYS } from './lib/storage';

const TUESDAY = '2026-10-27'; // Back & biceps

beforeEach(() => localStorage.clear());
afterEach(() => cleanup());

describe('progress survives a refresh', () => {
  it('keeps ticks, reps and completion after the app is closed and reopened', async () => {
    const user = userEvent.setup();

    // Session 1: tick two exercises, enter reps, complete the workout.
    const first = render(<App todayKey={TUESDAY} />);
    expect(screen.getByRole('heading', { name: 'Back & biceps' })).toBeInTheDocument();

    await user.click(screen.getByRole('checkbox', { name: 'Mark Prone Y raises done' }));
    await user.click(screen.getByRole('checkbox', { name: 'Mark Reverse snow angels done' }));
    await user.type(screen.getByRole('textbox', { name: 'Prone Y raises set 1 reps' }), '12');
    await user.type(screen.getByRole('textbox', { name: 'Prone Y raises set 2 reps' }), '10');
    await user.click(screen.getByRole('button', { name: 'Mark workout complete' }));
    expect(screen.getByText('Workout complete')).toBeInTheDocument();

    // It reached localStorage.
    const raw = localStorage.getItem(KEYS.workouts);
    expect(raw).not.toBeNull();
    expect(JSON.parse(raw!)[TUESDAY].completed).toBe(true);

    // "Refresh": throw the whole React tree away and mount a fresh one.
    first.unmount();
    render(<App todayKey={TUESDAY} />);

    expect(screen.getByRole('checkbox', { name: 'Mark Prone Y raises done' })).toBeChecked();
    expect(screen.getByRole('checkbox', { name: 'Mark Reverse snow angels done' })).toBeChecked();
    expect(screen.getByRole('checkbox', { name: 'Mark Prone T raises done' })).not.toBeChecked();
    expect(screen.getByRole('textbox', { name: 'Prone Y raises set 1 reps' })).toHaveValue('12');
    expect(screen.getByRole('textbox', { name: 'Prone Y raises set 2 reps' })).toHaveValue('10');
    expect(screen.getByRole('textbox', { name: 'Prone Y raises set 3 reps' })).toHaveValue('');
    expect(screen.getByText('Workout complete')).toBeInTheDocument();
    expect(screen.getByText('2 of 4 ticked')).toBeInTheDocument();
  });

  it('keeps each day separate and shows saved data when you open that day later', async () => {
    const user = userEvent.setup();

    const first = render(<App todayKey={TUESDAY} />);
    await user.click(screen.getByRole('checkbox', { name: 'Mark Prone T raises done' }));
    first.unmount();

    // Reopen on a later day; Tuesday's data should still be there when selected.
    render(<App todayKey="2026-10-29" />);
    expect(screen.getByRole('heading', { name: 'Chest, shoulders & triceps' })).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: 'Mark Push-ups done' })).not.toBeChecked();

    await user.click(screen.getByRole('button', { name: /^Tuesday, 27 October/ }));
    expect(screen.getByRole('checkbox', { name: 'Mark Prone T raises done' })).toBeChecked();
  });

  it('saves when the Save progress button is pressed', async () => {
    const user = userEvent.setup();
    render(<App todayKey={TUESDAY} />);
    await user.click(screen.getByRole('button', { name: 'Save progress' }));
    expect(localStorage.getItem(KEYS.workouts)).toBe('{}');
    expect(screen.getByRole('status')).toHaveTextContent(/Saved at/);
  });

  it('starts clean instead of crashing when stored data is corrupted', () => {
    localStorage.setItem(KEYS.workouts, '{not valid json');
    render(<App todayKey={TUESDAY} />);
    expect(screen.getByRole('heading', { name: 'Back & biceps' })).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: 'Mark Prone Y raises done' })).not.toBeChecked();
  });
});
